package aula5;

import java.util.Scanner;

public class prepADO2 {
    public static void main(String[] args) throws Exception {
        
        Scanner leia = new Scanner(System.in);
        
        System.out.println("Escolha um número");
        System.out.println("------------------------------");
        System.out.println("1\n2\n3\n4\n5\n6\n7");
        int escolha = leia.nextInt();

        switch(escolha){
            case 1:
                System.out.println("\nVocê escolheu a Segunda-feira");
            break;

            case 2:
                System.out.println("\nVocê escolheu a Terça-feira");
            break;

            case 3:
                System.out.println("\nVocê escolheu a Quarta-feira");
            break;

            case 4:
                System.out.println("\nVocê escolheu a Quinta-feira");
            break;

            case 5:
                System.out.println("\nVocê escolheu a Sexta-feira");
            break;

            case 6:
                System.out.println("\nVocê escolheu o Sábado");
            break;

            case 7:
                System.out.println("\nVocê escolheu o Domingo");
            break;

            default:
                System.out.println("\nValor inválido!");
            
        }
    }
}
