package aula5;

import java.util.Scanner;

public class prepADO2_ex2 {
    public static void main(String[] args) throws Exception{

        Scanner leia = new Scanner (System.in);

        System.out.println("QUESTÃO Nº 1 - BANCO DE DADOS");
        System.out.println("Sobre os tipos de dados, é correto afirmar que o tipo VARCHAR é:");
        System.out.println("a) Armazena apenas números inteiros");
        System.out.println("b) Armazena dados alfanuméricos");
        System.out.println("c) Armazena imagens e PDFs");
        System.out.println("d) É indicado para armazenar números fracionários e trabalhar com cálculos");
        System.out.println("e) É indicado para armazenar datas e horários");
        System.out.print("Escolha uma opção: ");
        char escolha = leia.next().charAt(0);
        switch (escolha){
            case 'b':
                System.out.println("Você acertou!");
            break;

            default:
                System.out.println("Você errou!");
        }
    }

}
