package aula5;

import java.util.Scanner;

public class rpgDesafio_aula5 {
    public static void main(String[] args) throws Exception {
                
        Scanner leia = new Scanner(System.in);

        System.out.println("--------------------------");
        System.out.print("Escolha o caminho a seguir");
        System.out.print("\n1 - Caverna");
        System.out.print("\n2 - Lago");
        System.out.print("\n3 - Ruínas");
        System.out.println("\n4 - Montanhas");
        int escolha = leia.nextInt();
        
        switch (escolha) {
            case 1:
                System.out.print("Você entrou na caverna e encontrou um dragão adormecido!");
            break;

            case 2:
                System.out.print("Você chegou ao lago e encontrou o espírito da água que lhe oferece uma poção!");
            break;

            case 3:
                System.out.print("Você encontrou ruínas antigas e um baú com artefato mágico!");
            break;

            case 4:
                System.out.print("Você atravessou as montanhas geladas e encontrou um antigo templo onde uma espada lendária repousa em um altar de pedra!");
            break;

            default:
                System.out.print("Caminho desconhecido, você se perdeu na floresta!");
        }
    }
}
